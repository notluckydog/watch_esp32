#ifndef __INC_FASTLED_ARM_MXRT1062_H
#define __INC_FASTLED_ARM_MXRT1062_H

#include "fastpin_arm_mxrt1062.h"
#include "fastspi_arm_mxrt1062.h"
#include "clockless_arm_mxrt1062.h"
#include "block_clockless_arm_mxrt1062.h"

#endif
